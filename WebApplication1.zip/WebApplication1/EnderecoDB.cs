﻿using Microsoft.EntityFrameworkCore;

class EnderecoDB : DbContext
{
    public EnderecoDB(DbContextOptions<EnderecoDB> options)
        : base(options) { }

    public DbSet<Endereco> Enderecos => Set<Endereco>();
}
