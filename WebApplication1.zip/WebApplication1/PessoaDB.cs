﻿using Microsoft.EntityFrameworkCore;

class PessoaDB : DbContext
{
    public PessoaDB(DbContextOptions<PessoaDB> options)
        : base(options) { }

    public DbSet<Pessoa> Pessoas => Set<Pessoa>();
}
