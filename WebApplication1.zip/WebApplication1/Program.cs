using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<PessoaDB>(opt => opt.UseInMemoryDatabase("Pessoa"));

builder.Services.AddDbContext<EnderecoDB>(opt => opt.UseInMemoryDatabase("Endereco"));

var app = builder.Build();

app.MapPost("/pessoas", async (Pessoa pessoa, PessoaDB db) =>
{
    db.Pessoas.Add(pessoa);
    await db.SaveChangesAsync();
    return Results.Created($"/pessoas/{pessoa.Id}", pessoa);
});

app.MapGet("/pessoas", async (PessoaDB db) =>
    await db.Pessoas.ToListAsync());

app.MapGet("/pessoas/{id}", async (int id, PessoaDB db) =>
{
    var pessoa = await db.Pessoas.FindAsync(id);
    return pessoa is not null ? Results.Ok(pessoa) : Results.NotFound();
});

app.MapDelete("/pessoas/{id}", async (int id, PessoaDB db) =>
{
    var pessoa = await db.Pessoas.FindAsync(id);
    if (pessoa is null) return Results.NotFound();

    db.Pessoas.Remove(pessoa);
    await db.SaveChangesAsync();
    return Results.NoContent();
});

app.MapPost("/enderecos", async (Endereco endereco, EnderecoDB db) =>
{
    db.Enderecos.Add(endereco);
    await db.SaveChangesAsync();
    return Results.Created($"/enderecos/{endereco.Id}", endereco);
});

app.MapGet("/enderecos", async (EnderecoDB db) =>
    await db.Enderecos.ToListAsync());

app.MapGet("/enderecos/{id}", async (int id, EnderecoDB db) =>
{
    var endereco = await db.Enderecos.FindAsync(id);
    return endereco is not null ? Results.Ok(endereco) : Results.NotFound();
});

app.MapDelete("/enderecos/{id}", async (int id, EnderecoDB db) =>
{
    var endereco = await db.Enderecos.FindAsync(id);
    if (endereco is null) return Results.NotFound();

    db.Enderecos.Remove(endereco);
    await db.SaveChangesAsync();
    return Results.NoContent();
});

app.Run();

